Display Bookshelves

Problem Statement : Display Bookshelves

Site: urbanladder.com  

Detailed Description:
====================

1.Display the name and price of Bookshelves below Rs. 15000, including out of stock and storage type as open.
2.Display the first 3 bookshelves below Rs. 15000 with open storage type excluding out of stock items.
3.Retrieve all sub-menu items under Being-At-home and store in a List; Display the same.
	1.Open the browser
	2.Go to "urbanladder.com".
	3.Enter "being at home" in searchBox.
	4.Click on search Box.
	5.Click on the category dropdown.
	6.Retrieve all the sub-Menu inside category dropdown.
	7.Display all the sub-Menu.
5.Display the name and price of first 3 study chairs with highest recommendation.
6.Navigate to the check-out page of a product; fill all the details with any one input invalid (example: email); Capture & display the error message.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Key Automation Scope:
====================

Handling alert, drag & drop, search option
Extract menu items & store in collections
Navigating back to home page
Scrolling down in web page
Filling form (in different objects in web page)
Capture warning message
------------------------------------------------------------------------------------------------------------------------------------------------------------

Other Notes :-

1. This project can execute TestCases on diffrent browsers

⦁ Steps to configure test execution for diferent browsers:

1. Check if there is Browser executable(web driver file) is in drivers folder.if not paste webdriver of the respective browser with special care of installed version of browser in your computer.

2. Change the name of the browser  variable in 	config.properties file  Located into the resources folder.
			1. edge    = Microsoft Edge
			2. chrome  = Google Chrome browser
		note: chrome and edge is not added add it manually in drivers folder.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Packages, Class and Methods Definitions:
=======================================

com.cts.urbanladder.pages
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class BasePage
=============

BasePage(WebDriver driver)			desc: Constructor that initializes the WebDriver, Actions, JavascriptExecutor, and WebDriverWait instances, and sets 									up PageFactory elements.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class BeingAtHome_Checkout_Page
==============================

BeingAtHome_Checkout_Page(WebDriver driver)		desc: Constructor that initializes the page elements and inherits from BasePage.
addToCartClick()								desc: Clicks the "Add to Cart" button.
checkOutClick()									desc: Clicks the "Checkout" button.
inputEmail(String email)						desc: Enters the provided email into the email field.
inputZip(String zip)							desc: Enters the provided zip code into the zip code field.
inputAddress(String addr)						desc: Enters the provided address into the address field.
inputFirstName(String fname)					desc: Enters the provided first name into the first name field.
inputLastName(String lname)						desc: Enters the provided last name into the last name field.
inputPhone(String ph)							desc: Enters the provided phone number into the phone field.
submitClick()									desc: Clicks the submit button.
errorMsgEvent()									desc: Retrieves and returns the error message text.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class BeingAtHome_Page
=====================

BeingAtHome_Page(WebDriver driver)		desc: Constructor that initializes the page elements and inherits from BasePage.
hoverOverDesc()							desc: Hovers over the description element.
optionsClick()							desc: Clicks the info link.
closingAd()								desc: Waits for the ad to be visible and closes it if displayed.
smallPopupHandle()						desc: Handles and closes the small popup using JavaScript to access the shadow root.
dropDownClick()							desc: Clicks the dropdown box.
listDisplay()							desc: Retrieves and returns the text of all elements in the list.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class Bookshelves_Page
=====================

Bookshelves_Page(WebDriver driver)		desc: Constructor that initializes the page elements and inherits from HomePage.
storageHover()							desc: Hovers over the storage type box.
storageTypeClick()						desc: Waits for the open storage option to be clickable and clicks it.
priceHover()							desc: Waits for the price box to be clickable, scrolls to it, and hovers over it.
priceSliderEvent()						desc: Waits for the max slider to be visible, scrolls to it, and adjusts the slider.
clickexcludestock()						desc: Waits for the stock checkbox to be visible and clicks it if not already selected.
getBookShelfNames()						desc: Retrieves and returns the list of bookshelf names.
getBookShelfPrices()					desc: Retrieves and returns the list of bookshelf prices.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class HomePage
=============

HomePage(WebDriver driver)			desc: Constructor that initializes the page elements and inherits from BasePage.
searchBoxEvent(String text)			desc: Enters the provided text into the search box.
searchBoxClick()					desc: Clicks the search button.
bookshelvesClick()					desc: Clicks the bookshelves link.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class StudyChairs_Page
=====================

StudyChairs_Page(WebDriver driver)		desc: Constructor that initializes the page elements and inherits from BasePage.
titlesDisplay()							desc: Retrieves and returns the text of the first three titles from the titles list.
pricesDisplay()							desc: Retrieves and returns the text of the first three prices from the price list.
------------------------------------------------------------------------------------------------------------------------------------------------------------

com.cts.urbanladder.setup
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class ExcelUtil
==============

getRowCount()					desc: Opens the specified Excel file and sheet, retrieves the number of rows, and then closes the file.
getCellCount()					desc: Opens the specified Excel file and sheet, retrieves the number of cells in the specified row, and then closes the file.
getCellData()					desc: Opens the specified Excel file and sheet, retrieves the data from the specified cell, formats it as a string, and then 								closes the file.
setCellData()					desc: Opens the specified Excel file and sheet, sets the data in the specified cell, writes the changes to the file, and then 								closes the file.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class ExtentReport
=================

onStart(ITestContext testContext)		desc: Initializes the ExtentSparkReporter and ExtentReports, sets system information, and configures the report.
onTestSuccess(ITestResult result)		desc: Creates a test entry in the report and logs the success status.
onTestFailure(ITestResult result)		desc: Creates a test entry in the report, logs the failure status, and captures a screenshot.
onTestSkipped(ITestResult result)		desc: Creates a test entry in the report and logs the skipped status.
onFinish(ITestContext testContext)		desc: Flushes the report and opens it in the default browser.
------------------------------------------------------------------------------------------------------------------------------------------------------------

com.cts.urbanladder.test
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class BeingAtHomeTest
====================

searchBeingAtHome()					desc: Searches for "Being At Home" using data from an Excel sheet and clicks the search button.
displaySubMenuItems()				desc: Clicks the dropdown and displays the sub-menu items.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class BookshelvesExcludeTest
===========================

openBookshelvesPage()				desc: Opens the bookshelves page by clicking the bookshelves link on the home page.
closeAd()							desc: Closes any visible advertisements on the bookshelves page.
filterBookshelves()					desc: Applies filters for storage type, price, and excludes out-of-stock items.
printBookshelvesDetails()			desc: Prints the names and prices of the first three bookshelves that are in stock.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class BookshelvesTest
=====================

openBookshelvesPage()				desc: Opens the bookshelves page by clicking the bookshelves link on the home page.
closeAd()							desc: Closes any visible advertisements on the bookshelves page.
filterBookshelves()					desc: Applies filters for storage type and price.
printBookshelvesDetails()			desc: Prints the names and prices of the first three bookshelves below 15,000.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class CheckOutTest
=================

searchBeingAtHome()					desc: Searches for "Being At Home" using data from an Excel sheet and clicks the search button.
handleBeingAtHomePage()				desc: Handles various interactions on the Being At Home page, including hovering over the description, clicking options, 								handling a small popup, and closing ads.
proceedToCheckout()					desc: Proceeds to checkout by adding an item to the cart, entering user details from an Excel sheet, and submitting the form, 								then prints any error message.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class DriverSetup
=================

setup()							desc: Initializes the WebDriver based on the configuration properties and opens the specified URL.
tearDown()						desc: Quits the WebDriver.
------------------------------------------------------------------------------------------------------------------------------------------------------------

Class StudyChairsTest
====================

searchStudyChairs()					desc: Searches for study chairs using data from an Excel sheet and clicks the search button.
displayStudyChairsDetails()			desc: Displays the titles and prices of the first three study chairs.
------------------------------------------------------------------------------------------------------------------------------------------------------------
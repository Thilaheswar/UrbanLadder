package com.cts.urbanladder.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cts.urbanladder.pages.BasePage;
import com.cts.urbanladder.pages.BeingAtHome_Page;
import com.cts.urbanladder.pages.Bookshelves_Page;
import com.cts.urbanladder.pages.HomePage;
import com.cts.urbanladder.setup.DriverSetup;

public class BookshelvesExcludeTest {
	
	BasePage bp;
	HomePage hp;
	BeingAtHome_Page bahp;
	Bookshelves_Page bsp;
	WebDriver driver;
	
	@BeforeClass
	public void setUp() throws IOException {
		driver= DriverSetup.setup();
		hp = new HomePage(driver);
		bp = new BasePage(driver);
		bahp= new BeingAtHome_Page(driver);
		bsp= new Bookshelves_Page(driver);
		
	}
	
	@Test(priority = 1)
    public void openBookshelvesPage() {
        hp.bookshelvesClick();
    }
    
    @Test(priority = 2, dependsOnMethods = "openBookshelvesPage")
    public void closeAd() {
        bahp.closingAd();
    }
    
    @Test(priority = 3, dependsOnMethods = "closeAd")
    public void filterBookshelves() {
        
        bsp.storageHover();
        bsp.storageTypeClick();
        bsp.priceHover();
        bsp.priceSliderEvent();
        bsp.clickexcludestock();
    }
    
    @Test(priority = 4, dependsOnMethods = "filterBookshelves")
    public void printBookshelvesDetails() throws InterruptedException {
        List<WebElement> li = bsp.getBookShelfNames();
        List<WebElement> li2 = bsp.getBookShelfPrices();
        System.out.println("Name and price of bookShelves excluding out of stock");
        System.out.println("-----------------------------------------------------");
        System.out.println("");
        Map<String, String> productMap = new HashMap<String, String>(); 
        
        for (int i = 0; i <= 2; i++) {
            productMap.put(li.get(i).getText(), li2.get(i).getText());
        }
        for (String key : productMap.keySet()) {
            System.out.println("Product Name: " + key + ", Price: " + productMap.get(key));
            System.out.println();
        }
        System.out.println("------------------------------------------------------");
    }
    
    @AfterClass
    public void tearDown() {
    	driver.quit();
    }

}

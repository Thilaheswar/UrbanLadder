package com.cts.urbanladder.pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
 
public class Bookshelves_Page extends HomePage{
	
	public Bookshelves_Page(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath="//*[@id='filters-form']/div[1]/div/div/ul/li[2]")
	WebElement storageTypeBox;
	
	@FindBy(id="filters_storage_type_Open")
	WebElement openStorage;
	
	@FindBy(xpath="//*[@id='filters-form']/div[1]/div/div/ul/li[1]")
	WebElement priceBox;
	
	@FindBy(xpath="//*[@id='filters-form']/div[1]/div/div/ul/li[1]/div[2]/div/div/ul/li[1]/div/div[2]/div[2]/div/div[2]/div")
	WebElement maxSlider;
	
	@FindBy(xpath="//*[@id='filters_availability_In_Stock_Only']")
	WebElement stock;
	
	By titlesList=By.xpath("//*[@id='content']/div[3]/ul/li/div/div[5]/a/div[1]");
	By priceList=By.xpath("//*[@id='content']/div[3]/ul/li/div/div[5]/a/div[2]/span");
	
	public void storageHover() {
		a.moveToElement(storageTypeBox).perform();
	}
	public void storageTypeClick() {
		wait.until(ExpectedConditions.elementToBeClickable(openStorage));
		openStorage.click();
	}
	public void priceHover() {
		wait.until(ExpectedConditions.elementToBeClickable(priceBox));
    	js.executeScript("arguments[0].scrollIntoView(true);", priceBox);
        a.moveToElement(priceBox).perform();
	}
	public void priceSliderEvent() {
		wait.until(ExpectedConditions.visibilityOf(maxSlider));
        js.executeScript("arguments[0].scrollIntoView(true);", maxSlider);     
        a.clickAndHold(maxSlider).moveByOffset(-271, 0).release().perform();
	}
	public void clickexcludestock(){
		wait.until(ExpectedConditions.visibilityOf(stock));
		Boolean isSelected = (Boolean) js.executeScript("return arguments[0].checked;", stock);
        if (!isSelected) {
            js.executeScript("arguments[0].click();", stock);
        }
		//js.executeScript("arguments[0].scrollIntoView(true);", stock);
		//stock.click();
    }
	public List<WebElement> getBookShelfNames() {
  	  return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(titlesList));
    }
 // Method to get the list of bookshelf prices
    public List<WebElement> getBookShelfPrices() {
        return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(priceList));

    }  
}
 

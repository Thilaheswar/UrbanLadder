package com.cts.urbanladder.test;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cts.urbanladder.pages.BeingAtHome_Page;
import com.cts.urbanladder.pages.HomePage;
import com.cts.urbanladder.setup.DriverSetup;
import com.cts.urbanladder.util.ExcelUtil;

public class BeingAtHomeTest {
	WebDriver driver;
	HomePage hp;
	BeingAtHome_Page bahp;
	
	
	// This method sets up the WebDriver and initializes the HomePage and beingAtHome_Page object
	@BeforeClass
	public void setUp() throws Exception {
		driver= DriverSetup.setup();
		hp = new HomePage(driver);
		bahp= new BeingAtHome_Page(driver);
	}
	
	// This test method searches for "Being At Home" using data from an Excel file
	@Test(priority = 1)
    public void searchBeingAtHome() throws Exception {
		String location=System.getProperty("user.dir")+"//src//test//resources//Data.xlsx";
        hp.searchBoxEvent(ExcelUtil.getCellData(location, "Sheet2", 1, 0));
        hp.searchBoxClick();
        
    }
    
	// This test method displays the sub-menu items after performing a search
    @Test(priority = 2, dependsOnMethods = "searchBeingAtHome")
    public void displaySubMenuItems() throws Exception {
        bahp.closingAd();
        Thread.sleep(5000);
        bahp.dropDownClick();
        List<String> items = bahp.listDisplay();
        
     // Assert that the sub-menu items list is not empty
        Assert.assertFalse(items.isEmpty(), "Sub-menu items list is empty.");
        System.out.println("Sub-menu Items:\n");
        for (String item : items) {
            System.out.println(item);
        }
        System.out.println("------------------------------------------------------");
    }
    
    
    // This method closes the browser after all tests are done
    @AfterClass
    public void tearDown() {
    	driver.quit();
    }

}



package com.cts.urbanladder.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cts.urbanladder.pages.BasePage;
import com.cts.urbanladder.pages.BeingAtHome_Checkout_Page;
import com.cts.urbanladder.pages.BeingAtHome_Page;
import com.cts.urbanladder.pages.HomePage;
import com.cts.urbanladder.setup.DriverSetup;
import com.cts.urbanladder.util.ExcelUtil;

public class CheckOutTest{
	
	private String location=System.getProperty("user.dir")+"//src//test//resources//Data.xlsx";
	BasePage bp;
	HomePage hp;
	BeingAtHome_Checkout_Page bcp;
	BeingAtHome_Page bahp;
	WebDriver driver;
	
	@BeforeClass
	public void setUp() throws IOException {
		driver= DriverSetup.setup();
		hp = new HomePage(driver);
		bp = new BasePage(driver);
		bcp= new BeingAtHome_Checkout_Page(driver);
		bahp= new BeingAtHome_Page(driver);
		
	}

	@Test(priority = 1)
    public void searchBeingAtHome() throws IOException {
        hp.searchBoxEvent(ExcelUtil.getCellData(location, "Sheet2", 1, 0));
        hp.searchBoxClick();
    }
    
    @Test(priority = 2, dependsOnMethods = "searchBeingAtHome")
    public void handleBeingAtHomePage() throws InterruptedException {
        
        bahp.hoverOverDesc();
        bahp.optionsClick();
        bahp.smallPopupHandle();
        bahp.closingAd();
    }
    
    @Test(priority = 3, dependsOnMethods = "handleBeingAtHomePage")
    public void proceedToCheckout() throws IOException {
        bcp.addToCartClick();
        bcp.checkOutClick();
        bcp.inputEmail(ExcelUtil.getCellData(location, "Sheet1", 1, 1));
        bcp.inputZip(ExcelUtil.getCellData(location, "Sheet1", 2, 1));
        bcp.inputAddress(ExcelUtil.getCellData(location, "Sheet1", 3, 1));
        bcp.inputFirstName(ExcelUtil.getCellData(location, "Sheet1", 4, 1));
        bcp.inputLastName(ExcelUtil.getCellData(location, "Sheet1", 5, 1));
        bcp.inputPhone(ExcelUtil.getCellData(location, "Sheet1", 6, 1));
        bcp.submitClick();
        System.out.println("Error Message: " + bcp.errorMsgEvent());
        System.out.println("------------------------------------------------------");
    }
    @AfterClass
    public void tearDown() {
    	driver.quit();
    }

}

package com.cts.urbanladder.setup;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class DriverSetup {
	private static WebDriver driver=null; // instance variable which will hold the reference of webdriver
	public String location=System.getProperty("user.dir")+"//src//test//resources//Data.xlsx"; //location of excel
	
	@BeforeClass // which will run before all the test methods every time.
	public static WebDriver setup() throws IOException { // setting up the broswer which will return the null value
		Properties properties = new Properties(); // this is the instance of properties which will hold the configuration setting.
	    FileInputStream inputStream = new FileInputStream("src/test/resources/config.properties"); ;// read the excel
	    properties.load(inputStream); // load the excel
	    String driverType=properties.getProperty("driver"); // this method will find the value of key=(driver) & value=chrome.
	    String url=properties.getProperty("url"); // this method will find the value of key=(url) & value=link.
	    switch(driverType.toLowerCase()) {
	    	case "chrome":
	    		driver=new ChromeDriver(); // initialize the Chrome
	    		break;
	    	case "edge":
	    		driver=new EdgeDriver();// initialize the Edge
	    		break;
	    }
		driver.get(url); //used to load a web page in the browser
		driver.manage().window().maximize(); // Maximize the tab 
		return driver;
	}
	
	@AfterClass
	void tearDown() {
		driver.quit(); //will close all the tabs and browser.
	}
}
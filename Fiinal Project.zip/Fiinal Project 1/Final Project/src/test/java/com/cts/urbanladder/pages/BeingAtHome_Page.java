package com.cts.urbanladder.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class BeingAtHome_Page extends BasePage{
	 
	// Constructor to initialize the WebDriver
	public BeingAtHome_Page(WebDriver driver) {
		super(driver);
	}
	
	// WebElement for the product description
	@FindBy(xpath="//a[@class='product-title-block']/div/span")
	WebElement desc;
	
	// WebElement for additional information link
	@FindBy(xpath="//div[@class='otherinfo']/a[2]")
	WebElement info;
	
	// WebElement for closing the popup advertisement
	@FindBy(xpath="//div[@class='vert-container']/div[2]/a")
	WebElement popupAdClose;
	
	// WebElement for the dropdown box
	@FindBy(xpath="//div[@class='caret']")
	WebElement dropDownBox;
	
	// WebElement for the small popup
	@FindBy(tagName="ct-web-popup-imageonly")
	WebElement smallPopup;
	
	// List of WebElements for the options in the dropdown
	@FindBy(xpath="//ul[@class='clearfix options']/li//label")
	List<WebElement> list;

	// Method to hover over the product description
	public void hoverOverDesc() {
		Actions a=new Actions(driver);
		a.moveToElement(desc).perform();
	}
	
	// Method to click on the additional information link
	public void optionsClick() {
		info.click();
	}
	
	// Method to close the popup advertisement
	public void closingAd() {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='vert-container']")));
		
		try 
		{
			if(popupAdClose.isDisplayed())
			{
				popupAdClose.click();
			}
		}
		catch(Exception e)	{}
		
	}
	
	// Method to handle the small popup using JavaScript
	public void smallPopupHandle() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='vert-container']")));
        // Use JavaScript to access the shadow root
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement shadowElement = (WebElement) js.executeScript(
                "return arguments[0].shadowRoot.querySelector('#close')", smallPopup);
 
        // Perform actions on the shadow element (e.g., click it)
        shadowElement.click();
	}
	
	// Method to click on the dropdown box
	public void dropDownClick() {
		wait.until(ExpectedConditions.visibilityOf(dropDownBox));
		dropDownBox.click();
	}
	
	// Method to display the list of options in the dropdown
	public List<String> listDisplay() {
		List<String> li=new ArrayList<>();
		for(WebElement i:list) {
			li.add(i.getText());
		}
		return li;
	}

}

package com.cts.urbanladder.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{ // home page is the child of base page
	
	public HomePage(WebDriver driver) {
		// constructor of home page which will call the constructor of base page with the help of super keyword and pass the webdriver object to it.
		super(driver);	
	}
	@FindBy(id="search")
	WebElement searchBox;
	
	@FindBy(id="search_button")
	WebElement searchBtn;
	
	@FindBy(xpath="//div[@class='categories row']/a[7]/img")
	WebElement bookshelvesLink;
	
	public void searchBoxEvent(String text) {
		searchBox.sendKeys(text);
	}
	public void searchBoxClick() {
		searchBtn.click();
	}
	public void bookshelvesClick() {
		bookshelvesLink.click();
	}

}

package com.cts.urbanladder.test;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.cts.urbanladder.pages.HomePage;
import com.cts.urbanladder.pages.StudyChairs_Page;
import com.cts.urbanladder.setup.DriverSetup;
import com.cts.urbanladder.util.ExcelUtil;

public class StudyChairsTest{
	
	private String location=System.getProperty("user.dir")+"//src//test//resources//Data.xlsx";
	WebDriver driver;
	HomePage hp;
	StudyChairs_Page scp;
	@BeforeClass
	public void setUp() throws IOException {
		driver= DriverSetup.setup();
		hp = new HomePage(driver);
		scp= new StudyChairs_Page(driver);
	}
	
	@Test(priority = 1)
    public void searchStudyChairs() throws IOException {
        hp.searchBoxEvent(ExcelUtil.getCellData(location, "Sheet2", 0, 0));
        hp.searchBoxClick();
    }
    
    @Test(priority = 2, dependsOnMethods = "searchStudyChairs")
    public void displayStudyChairsDetails() throws InterruptedException {
        
        List<String> titles = scp.titlesDisplay();
        List<String> prices = scp.pricesDisplay();
        System.out.println("Study Chairs:");
        for (int i = 0; i < titles.size(); i++) {
            System.out.println("Title: " + titles.get(i));
            System.out.println("Price: " + prices.get(i));
            System.out.println();
        }
        System.out.println("------------------------------------------------------");
    }
    @AfterClass
    public void tearDown() {
    	driver.quit();
    }

}

package com.cts.urbanladder.pages;

import java.util.ArrayList;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StudyChairs_Page extends BasePage{
	
	public StudyChairs_Page(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(xpath="//div[@class='product-info-block']/a/div/span[@class='name']")
	List<WebElement> titlesList;
	
	@FindBy(xpath="//div[@class='product-info-block']/a/div[2]/span")
	List<WebElement> priceList;
	
	public List<String> titlesDisplay(){
		List<String> li=new ArrayList<>();
		for(int i=0;i<3;i++) {
			li.add(titlesList.get(i).getText());
		}
		return li;
	}
	public List<String> pricesDisplay(){
		List<String> li=new ArrayList<>();
		for(int i=0;i<3;i++) {
			li.add(priceList.get(i).getText());
		}
		return li;
	}
	

}

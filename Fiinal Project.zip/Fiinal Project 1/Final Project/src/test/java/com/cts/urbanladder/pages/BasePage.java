package com.cts.urbanladder.pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	// instance variable which will hold the reference of webdriver,action,js,webdriverwait object
	WebDriver driver;
    Actions a;
    JavascriptExecutor js;
    WebDriverWait wait;

    public BasePage(WebDriver driver) { 
        this.driver = driver; //assign the passed webdriver to the instance variable driver.
        this.a = new Actions(driver); // initialize the action with webdriver .
        this.js = (JavascriptExecutor) driver; // this will cast the js and assign it to js
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(60)); //this will initialize the wait with duration of 60 sec.
  
        
        // PageFactory is a predefined class in selenium and initelement is the static method.
        //This line will basically automates the process of finding and initializing the webelement.
        //used to initialize the web elements of a page object
        PageFactory.initElements(driver, this); 
    }

}
